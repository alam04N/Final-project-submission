let blockedCount = 0;
let userWhitelist = [];

// When extension is installed
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ blockedCount: 0 });
  console.log("Extension Installed");
});

// Load whitelist from storage
chrome.storage.sync.get(['whitelist'], (data) => {
  if (data.whitelist) {
    userWhitelist = data.whitelist;
  }
});

// Update badge text when blocking happens
function updateBadge() {
  chrome.action.setBadgeText({ text: blockedCount.toString() });
  chrome.storage.local.set({ blockedCount });
}

// Use Declarative Net Request API to block trackers
chrome.declarativeNetRequest.updateDynamicRules(
  {
    removeRuleIds: [1],
    addRules: [
      {
        id: 1,
        priority: 1,
        action: { type: "block" },
        condition: {
          urlFilter: "tracker.com",  // Example domain
          resourceTypes: ["script", "xmlhttprequest"]
        }
      }
    ]
  },
  () => {
    console.log("Blocking rules updated!");
  }
);