const input = document.getElementById('domainInput');
const addBtn = document.getElementById('addBtn');
const list = document.getElementById('whitelist');

function renderList(whitelist) {
  list.innerHTML = '';
  whitelist.forEach(domain => {
    const li = document.createElement('li');
    li.textContent = domain;
    list.appendChild(li);
  });
}

addBtn.onclick = () => {
  const domain = input.value.trim();
  if (!domain) return;

  chrome.storage.sync.get(['whitelist'], (data) => {
    let whitelist = data.whitelist || [];
    if (!whitelist.includes(domain)) {
      whitelist.push(domain);
      chrome.storage.sync.set({ whitelist }, () => {
        renderList(whitelist);
        input.value = '';
      });
    }
  });
};

// Load on open
chrome.storage.sync.get(['whitelist'], (data) => {
  renderList(data.whitelist || []);
});
