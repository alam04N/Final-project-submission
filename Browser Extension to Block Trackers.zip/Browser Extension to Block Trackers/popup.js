document.addEventListener('DOMContentLoaded', function () {
  chrome.storage.local.get(['blockedCount'], function (data) {
    document.getElementById('count').textContent = data.blockedCount || 0;
  });
});
